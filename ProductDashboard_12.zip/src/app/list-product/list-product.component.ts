import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {ProductService} from "../service/product.service";
import {Product} from "../model/product.model";


@Component({
  selector: 'app-list-product',
  templateUrl: './list-product.component.html'
  /*styleUrls: ['./list-product.component.css']*/
})
export class ListProductComponent implements OnInit {

    ListProductComponent = function () {
        function ListProductComponent() {
            this.products = new Product<products>();
            {
                new Product[1, "Mouse", "Logitech", 20]
                new Product[2, "XBox", "MicroSoft", 450]
                new Product[3, "Laptop", "Lenovo", 900]
                new Product[4, "Keyboard", "Logitech", 30]
                new Product[5, "PlayStation4", "Sony", 500]
            };
        }
        /* ListProductComponent = __decorate();*/
        return ListProductComponent;
    }

    products: Product[];
    /*Product[] products = new Product[]
       {
    new Product [  1,  "Mouse", "Logitech", 20 ]
    new Product [  2,  "XBox",  "MicroSoft",  450 ]
    new Product [ 3, "Laptop",  "Lenovo",  900 ]
    new Product [  4,  "Keyboard",  "Logitech",  30 ]
    new Product [  5,  "PlayStation4", "Sony",  500 ]
};*/

    constructor(private router: Router, private productService: ProductService) { }

    /*var ListProductComponent = /** @class */ /*(function () {
        function ListProductComponent() {
            this.products = new Product[];
        }
        ListProductComponent = __decorate([1, "Mouse", "Logitech", 20],
            [2, "XBox", "MicroSoft", 450],
            [3, "Laptop", "Lenovo", 900]
            [4, "Keyboard", "Logitech", 30]
            [5, "PlayStation4", "Sony", 500]);
        return ListProductComponent;
    })*/
    
    ngOnInit() {
        this.productService.getProducts()
            .subscribe(data => {
                this.products = data;
            });
    }

    deleteProduct(product: Product): void {
        this.productService.deleteProduct(product.id)
            .subscribe(data => {
                this.products = this.products.filter(u => u !== product);
            })
    };

    editProduct(product: Product): void {
        localStorage.removeItem("editProductId");
        localStorage.setItem("editProductId", product.id.toString());
        this.router.navigate(['edit-product']);
    };

    addProduct(): void {
        this.router.navigate(['add-product']);
    };

}
