import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ListProductComponent } from './list-product/list-product.component';
import {routing} from "./app.routing";
import { EditProductComponent } from './edit-product/edit-product.component';
import { AddProductComponent } from './add-product/add-product.component';
import { DeleteProductComponent } from './delete-product/delete-product.component';
import {ReactiveFormsModule} from "@angular/forms";
import {HttpClientModule} from "@angular/common/http";
import { MyNewComponentComponent } from './my-new-component/my-new-component.component';
import { MyNewDirectiveDirective } from './my-new-directive.directive';
import { MyNewPipePipe } from './my-new-pipe.pipe';
import {ProductService} from "./service/product.service";

@NgModule({
  declarations: [
    AppComponent,
    ListProductComponent,
    EditProductComponent,
    AddProductComponent,
    DeleteProductComponent,
    MyNewComponentComponent,
    MyNewDirectiveDirective,
    MyNewPipePipe
  ],
  imports: [
      BrowserModule,
      routing,
      ReactiveFormsModule,
      HttpClientModule
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
