export class MyNewClass {
}
