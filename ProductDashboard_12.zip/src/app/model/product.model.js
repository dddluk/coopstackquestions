﻿/*let products = [{ id : 1, name : "Mouse", brand : "Logitech", price : 20 },
      { id : 2, name : "XBox", brand : "MicroSoft", price : 450 },
      { id : 3, name :"Laptop", brand : "Lenovo", price : 900 },
      { id : 4, name : "Keyboard", brand : "Logitech", price : 30 },
      { id : 5, name : "PlayStation4", brand :"Sony", price : 500 },
];
return Observable.of(products).delay(5000);*/

var ListProductComponent = /** @class */ (function () {
    function ListProductComponent() {
        this.products = new Product[];
    }
    ListProductComponent = __decorate([  1,  "Mouse", "Logitech", 20 ],
        [  2,  "XBox",  "MicroSoft",  450 ],
        [ 3, "Laptop",  "Lenovo",  900 ]
        [  4,  "Keyboard",  "Logitech",  30 ]
        [  5,  "PlayStation4", "Sony",  500 ]);
    return ListProductComponent;
})
