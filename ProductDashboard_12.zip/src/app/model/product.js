﻿let companyProducts = [{ id : 1, name : "Mouse", brand : "Logitech", price : 20 },
      { id : 2, name : "XBox", brand : "MicroSoft", price : 450 },
      { id : 3, name :"Laptop", brand : "Lenovo", price : 900 },
      { id : 4, name : "Keyboard", brand : "Logitech", price : 30 },
      { id : 5, name : "PlayStation4", brand :"Sony", price : 500 },
];
return Observable.of(companyProducts).delay(5000);