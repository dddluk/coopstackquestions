export interface MyNewInterface {
}
