import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {ProductService} from "../service/product.service";
import {first} from "rxjs/operators";
import {Router} from "@angular/router";


@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})

export class AddProductComponent implements OnInit {

    constructor(private formBuilder: FormBuilder, private router: Router, private productService: ProductService) { }

    addForm: FormGroup;

    ngOnInit() {

        this.addForm = this.formBuilder.group({
            id: [],
            name: [],
            brand: [],
            price: []
        });  

        onSubmit() {
    this.productService.createProduct(this.addForm.value)
      .subscribe( data => {
        this.router.navigate(['list-user']);
      });  
  }

    }


}
